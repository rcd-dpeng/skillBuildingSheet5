/*******************************************************************************
* File Name: main.c
*
* Version: 1.10
*
* Description:
*  This is source code for example project of the SPI Master component.
*  Parameters used:
*   Mode                CPHA == 0, CPOL == 0                
*   Data lines          MOSI+MISO
*   Shift direction     MSB First
*   DataBits:           8 
*   Bit Rate            1 Mbps
*   Clock source        External 
*
*  SPI communication test using DMA. 8 bytes are transmitted
*  between SPI Master and SPI Slave.
*  Received data are displayed on LCD. 
*
********************************************************************************
* Copyright 2012-2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/
#include <project.h>


uint16 ReadEncoderValue(uint8);


CY_ISR(RPi_SS_Handler)
{
    /*  load the encoder position data into the transmit data registers*/
    Rpi_ss_ClearInterrupt();
  
    SPIS_ClearFIFO(); 
    SPIS_WriteTxDataZero(0x1234);
    SPIS_WriteTxData(0x5678);
    SPIS_WriteTxData(0x9abc);
    SPIS_WriteTxData(0xdef0);
}

CY_ISR(SPIS_FIFO_Handler)
{
   
/*    Routine to write to sig gen over SPI or Power Amp Gain over I2C */
    SPIS_ReadRxStatus();
    SPIS_ClearRxBuffer();
}


/* The txBuffer size is equal (BUFFER_SIZE-1) because for SPI Mode where CPHA == 0 and
* CPOL == 0 one byte writes directly in SPI TX FIFO using SPIS_WriteTxDataZero() API.
*/

uint16 rxBuffer [4];


 uint8 temp1;
 uint8 temp2;

uint16 enc_a_Position;
uint16 enc_b_Position;
uint16 enc_c_Position;

uint8 i;
uint16 shutdown_count;
/*******************************************************************************
* Function Name: main
********************************************************************************
*******************************************************************************/
int main()
{
    Comp_1_Start();
    CyDelay(2000u);
    /* Enable Battery Backup circuit and interface circuits between RPi and PSOC  */
    EnableBattery_Write(1u);
    Control_Reg_SS_Write(0u);
    Control_Reg_LED_Write(0u);
    RpiInterrupts_Write(3u);     
    Clock_1_Start();
    SPIM_1_Start();
    SPIM_1_ClearFIFO();
    SPIM_1_ClearRxBuffer();
    SPIM_1_ClearTxBuffer();   
    
    SPIM_SigGen_Start();
    SPIM_SigGen_ClearFIFO();
    SPIM_SigGen_ClearRxBuffer();
    SPIM_SigGen_ClearTxBuffer();
    

    SPIS_Start();
    SPIS_WriteTxDataZero(0x00u);
 
     I2C_1_Start();
    
    isr_RPi_SS_StartEx( RPi_SS_Handler );
    isr_SPIS_FIFO_Full_StartEx( SPIS_FIFO_Handler  );
    CyGlobalIntEnable; 
    
  
    shutdown_count = 0;

    while (1)  {
        
     /* read the encoder values  */     
      enc_a_Position = ReadEncoderValue(0u);    
      enc_b_Position = ReadEncoderValue(1u);        
      enc_c_Position = ReadEncoderValue(2u);
    
    
    /* This code monitors the main power input.  A local backup batter supply prevents  */
    /* power from being removed from the raspberry pi before it has been properly shutdown   */
    /* Monitor the presence of the main power input */    
    /*  If power has been removed for more than 5000 times through this loop -  -  about 20 seconds */
    /*  Interrupt the Raspberry Pi telling it to shut itself down  */
    /*  allow 20 sec for the Pi to shut down then turn off back up power. */
    CyDelayUs(1400u);
    
      if (Status_Reg_1_Read() == 1u) {
        shutdown_count +=1;
        if (shutdown_count == 5000u) {      
            CyGlobalIntDisable; 
             Control_Reg_LED_Write(1u);
            /* tell Pi to shut down */ 
           RpiInterrupts_Write(0u);
           CyDelay(20000u);
        /* Wait 60 seconds then turn off back up power */
           EnableBattery_Write(2u);
           CyDelay(2000u);
        }
      } else {
         shutdown_count =0u;
      }
    }
}

uint16 ReadEncoderValue(uint8 encoderNumber)
{
    uint16 result;
    uint8 ii;
       
      Control_Reg_SS_Write(encoderNumber);
      SPIM_1_ClearFIFO();
      SPIM_1_WriteTxData(0x10);       
      /*  wait for transmit of first data is finished  */
      while(!(SPIM_1_ReadTxStatus() & SPIM_1_STS_SPI_DONE));   
      CyDelayUs(20u);
      ii=0;
      while ((SPIM_1_ReadByte() != 0x10) & (ii<6)) {
          CyDelayUs(20u);
          SPIM_1_WriteTxData(0x00);  
          while(!(SPIM_1_ReadTxStatus() & SPIM_1_STS_SPI_DONE));
          ii+=1;
      }  
     /*  if ii > 6  means encoder did not respond -- possibly not hooked up*/
      if (ii<6) {
         CyDelayUs(20u);
         SPIM_1_WriteTxData(0x00);  
         while(!(SPIM_1_ReadTxStatus() & SPIM_1_STS_SPI_DONE));
         result = SPIM_1_ReadByte()*256;    
         CyDelayUs(20u);
         SPIM_1_WriteTxData(0x00);  
         while(!(SPIM_1_ReadTxStatus() & SPIM_1_STS_SPI_DONE));
         result += SPIM_1_ReadByte();          
         CyDelayUs(40u);
      } else {
         /*  note encoder word is 12 bits long.  0xF000 represents an invalid code  */
         result = 0xF000;
        CyDelayUs(40u);
      }    
    return(result);
}

/* [] END OF FILE */
